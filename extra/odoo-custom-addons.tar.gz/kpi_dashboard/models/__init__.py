from . import kpi_dashboard
from . import kpi_kpi
from . import ir_actions_act_window_view
from . import ir_ui_view
